#include <stdio.h>
#include <stdint.h>
#include <string.h>

int filterDivisibleNumbersAndSquare(int input[], int length, int divisor, int output[]) __attribute__((weak));


int trampoline_filterDivisibleNumbersAndSquare(int input[], int length, int divisor, int output[], int* failed_registers);
asm(
".intel_syntax noprefix\n"
"trampoline_filterDivisibleNumbersAndSquare:\n"
"   push ebp\n"
"   mov ebp, esp\n"
"   sub esp, 4*4\n"

"   mov [ebp - 4*1], ebx\n"
"   mov [ebp - 4*2], esi\n"
"   mov [ebp - 4*3], edi\n"

"   mov ebx, -1\n"
"   mov edi, -1\n"
"   mov esi, -1\n"

"   push dword ptr [ebp + 4*5]\n"
"   push dword ptr [ebp + 4*4]\n"
"   push dword ptr [ebp + 4*3]\n"
"   push dword ptr [ebp + 4*2]\n"
"   call filterDivisibleNumbersAndSquare\n"

"   mov edx, [ebp + 4*6]\n"
"   mov dword ptr [edx], 3\n"

"   cmp ebx, -1\n"
"   jnz R0\n"
"   dec dword ptr [edx]\n"
"R0:\n"

"   cmp esi, -1\n"
"   jnz R1\n"
"   dec dword ptr [edx]\n"
"R1:\n"

"   cmp edi, -1\n"
"   jnz R2\n"
"   dec dword ptr [edx]\n"
"R2:\n"

"   mov ebx, [ebp - 4*1]\n"
"   mov esi, [ebp - 4*2]\n"
"   mov edi, [ebp - 4*3]\n"

"   mov esp, ebp\n"
"   pop ebp\n"
"   ret\n"
".att_syntax\n"
);


int solution_filterDivisibleNumbersAndSquare(int input[], int length, int divisor, int output[]) {
    int outIdx = 0;
    for (int idx = 0; idx < length; idx++) {
        int value = input[idx];

        if ((value % divisor) == 0) {
            output[outIdx] = value * value;
            outIdx++;
        }
    }

    return outIdx;
}

void __print_int_array(char *output, int data[], int size) {
    int pos = 0;
    for (int idx = 0; idx < size; idx++) {
        pos += sprintf(output + pos, "%d, ", data[idx]);
    }
}

int __check_buffer(const void* buffer, uint8_t expected, int length) {
    const uint8_t* ptr = (const uint8_t*)buffer;
    const uint8_t* end = ptr + length;

    for (;ptr < end; ptr++) {
        if (*ptr != expected) {
            return ptr - (const uint8_t*)buffer;
        }
    }

    return -1;
}

int main() {
    struct testCase {
        int data[20];
        int length;
        int divisor;
        int expected[20];
        int expected_length;
    } tests[] = {
        { { 1, 2, 3, 4, 5 }, 5, 2, { 2*2, 4*4 }, 2 },
        { { 1, 2, 3, 4, 5 }, 5, 1, { 1*1, 2*2, 3*3, 4*4, 5*5 }, 5 },
        { { -1, -2, -3, -4, -5 }, 5, 2, { -2*-2, -4*-4 }, 2 },
        { { -1, -2, -3, -4, -5 }, 5, 1, { -1*-1, -2*-2, -3*-3, -4*-4, -5*-5 }, 5 },
        { { 3, 4, 5, 6, 7, 8 }, 6, 100, { }, 0 },
    };

    int test_count = sizeof(tests) / sizeof(tests[0]);
    int pass_count = 0;
    int fail_count = 0;

    for (int idx = 0; idx < test_count; idx++) {
        int output[30];
        memset(output, 0xFF, sizeof(output));

        int failed_registers = -1;
        int result_length = trampoline_filterDivisibleNumbersAndSquare(tests[idx].data, tests[idx].length, tests[idx].divisor, output, &failed_registers);

        int errors_found = 0;
        if (failed_registers != 0) {
            asm( "" : : : "ebx", "esi", "edi"); // make sure we can print out something
            printf("[ FAIL ] Incorrect cdecl usage: registers not correctly handled! (register count: %d)\n", failed_registers);
            errors_found++;
        }
        if (result_length != tests[idx].expected_length) {
            printf("[ FAIL ] Incorrect return value (returned: %d, expected: %d)\n", result_length, tests[idx].expected_length);
            errors_found++;
        }

        // Test values
        for (int ndx = 0; ndx < tests[idx].expected_length; ndx++) {
            if (tests[idx].expected[ndx] != output[ndx]) {
                errors_found++;
            }
        }

        char output_text[128] = { 0 };
        char expected_text[128] = { 0 };
        __print_int_array(output_text, output, result_length);
        __print_int_array(expected_text, tests[idx].expected, tests[idx].expected_length);

        printf("[ DEBG ] Testcase: %d. result: [ %s ]  (expected: [ %s ])\n", idx, output_text, expected_text);

        int overflow_position = __check_buffer(output + tests[idx].expected_length, 0xFF, 3);
        if (overflow_position != -1) {
            errors_found++;
            int absolute_position = sizeof(int) * tests[idx].expected_length + overflow_position;
            printf("[ DEBG ]  Error! Buffer overflow detected in output buffer (from byte: %d).\n", absolute_position);
        }

        if (errors_found == 0) {
            pass_count++;
        } else {
            fail_count++;
        }
    }

    printf("[ STAT ] Tests TOTAL: %3d\n", test_count);
    printf("[ STAT ] Tests PASSED: %3d (%6.2f%%)\n", pass_count, (pass_count * 100.0) / test_count);
    printf("[ STAT ] Tests FAILED: %3d (%6.2f%%)\n", fail_count, (fail_count * 100.0) / test_count);

    return 0;
}
